import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# Названия классов
label_names = ["French Bulldog", "Siberian Husky"]

# Загружаем модель
model = tf.keras.models.load_model('transfer_model/models2/transfer_model.keras')

# Подготовка изображения
def load_and_preprocess_image(path):
    img = Image.open(path).convert('RGB')
    img = img.resize((224, 224))
    img_array = np.array(img) / 255.0
    return np.expand_dims(img_array, axis=0), img

# Путь к изображению
image_path = 'transfer_model/test_samples2/pudel1.jpeg'  # замените при необходимости
input_tensor, original_img = load_and_preprocess_image(image_path)

# Предсказание
pred = model.predict(input_tensor)[0]           # [prob_bulldog, prob_husky]
pred_class = np.argmax(pred)                    # индекс: 0 или 1
confidence = pred[pred_class]                   # уверенность по выбранному классу

# Порог уверенности
threshold = 1.0

# Логика вывода
if confidence >= threshold:
    label = label_names[pred_class]
else:
    label = "Это не Хаски и не Бульдог"

# Консоль
print(f"\n Предсказано: {label}")
print(f"Уверенность: {confidence:.2%}")
print(f"Модель видит: {pred}")  # лог вероятностей

# Отображение
plt.imshow(original_img)
plt.title(f"{label} ({confidence:.1%})")
plt.axis('off')
plt.show()
