import tensorflow as tf
import tensorflow_datasets as tfds

IMG_SIZE = 224
BATCH_SIZE = 32

# Две выбранные породы: французский бульдог и сибирский хаски
TARGET_CLASSES = [94, 99]  # метки в оригинальном датасете
CLASS_MAPPING = {94: 0, 99: 1}  # булдог = 0, хаски = 1

def map_label(label):
    return CLASS_MAPPING[int(label.numpy())]

def preprocess(example):
    image = tf.image.resize(example['image'], (IMG_SIZE, IMG_SIZE))
    image = tf.keras.applications.mobilenet_v2.preprocess_input(image)
    
    label = example['label']
    mapped_label = tf.py_function(map_label, [label], tf.int64)
    mapped_label.set_shape([])  # очень важно
    
    # Преобразуем в one-hot вектор из 2 классов
    mapped_label = tf.one_hot(mapped_label, depth=2)
    
    return image, mapped_label


def load_filtered_dogs(split='train'):
    ds, info = tfds.load('stanford_dogs', split=split, with_info=True, shuffle_files=True)
    filtered_ds = ds.filter(lambda x: tf.reduce_any([x['label'] == cls for cls in TARGET_CLASSES]))
    return filtered_ds, info

def prepare_datasets():
    train_raw, _ = load_filtered_dogs('train')
    test_raw, _ = load_filtered_dogs('test')

    train_ds = (
        train_raw
        .map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
        .shuffle(1000)
        .batch(BATCH_SIZE)
        .prefetch(tf.data.AUTOTUNE)
    )

    test_ds = (
        test_raw
        .map(preprocess, num_parallel_calls=tf.data.AUTOTUNE)
        .batch(BATCH_SIZE)
        .prefetch(tf.data.AUTOTUNE)
    )

    train_size = train_raw.cardinality().numpy()
    test_size = test_raw.cardinality().numpy()

    return train_ds, test_ds, train_size, test_size
