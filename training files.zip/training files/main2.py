import tensorflow as tf
from tensorflow.keras import layers, models
from data_pipeline2 import prepare_datasets

# Загружаем датасеты
train_ds, test_ds, train_size, test_size = prepare_datasets()

print("Датасет загружен")
print(f" - Train size: {train_size}")
print(f" - Test size: {test_size}")

# Загружаем предобученную MobileNetV2 без головы
base_model = tf.keras.applications.MobileNetV2(
    input_shape=(224, 224, 3),
    include_top=False,
    weights='imagenet'
)
base_model.trainable = False  # замораживаем

# Создаем модель
model = models.Sequential([
    base_model,
    layers.GlobalAveragePooling2D(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.3),
    layers.Dense(2, activation='softmax')  #  два класса
])


print("Модель с MobileNetV2 создана")
model.summary()

# Компиляция
model.compile(
    optimizer='adam',
    loss='categorical_crossentropy',  # <— заменили
    metrics=['accuracy']
)


# Обучение
history = model.fit(
    train_ds,
    validation_data=test_ds,
    epochs=5
)

# Сохранение
model.save('models2/transfer_model.keras')
print("Модель с трансферным обучением сохранена!")

